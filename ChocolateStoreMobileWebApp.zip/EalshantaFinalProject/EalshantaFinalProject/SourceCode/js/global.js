// GlobAL - Eman AlShanta 7158256 - Web Mobile App Final Project


// global variable db used
var db;

// Calls when we have problem
function errorHandler(transaction, error)
{
    alert("SQL error: " + error.message);
}


// DOM is Ready
$(document).ready(function ()
{
    db = openDatabase('EalshantaFinalProjectDB', '1.0', 'Our Delicacy dataBase', 5 * 1024 * 1024);
    createTables();
    getItems();
    getCart();
    dropCartTable();

});